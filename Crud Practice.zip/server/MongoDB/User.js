import mongoose from "mongoose";

const UserSchema = mongoose.Schema(
    {
        name: String,
        email: String,
        age: Number,
    }
)

const userModel = mongoose.model("UserModel", UserSchema);

export default userModel;