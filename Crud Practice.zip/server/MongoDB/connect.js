import mongoose from "mongoose";

const connectDB = () => {
    mongoose.set('strictQuery', true)
    const username = encodeURIComponent("ZohaibALi");
    const password = encodeURIComponent("BatmanZ");
    const url = `mongodb+srv://${username}:${password}@zohaib.l058wz7.mongodb.net/?retryWrites=true&w=majority`

    mongoose.connect(url)
        .then(() => console.log("MongoDB connected"))
        .catch((err) => console.log(err));
}

export default connectDB;