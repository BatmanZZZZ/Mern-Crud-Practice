import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import connectDB from './MongoDB/connect.js';
import userModel from './MongoDB/User.js';

const app = express();
app.use(cors());
app.use(express.json()); // Place this middleware before your routes

app.get("/getUser/:id", (req, res) => {
    const id = req.params.id;
    userModel.findById(id)
        .then(result => res.json(result))
        .catch(err => res.json(err));
});

app.delete("/deleteUser/:id", (req, res) => {
    const id = req.params.id;
    userModel.findByIdAndDelete(id)
        .then(result => {
            if (!result) {
                // User with the specified ID was not found.
                return res.status(404).json({ error: "User not found" });
            }
            // User successfully deleted.
            return res.status(200).json({ message: "User deleted successfully" });
        })
        .catch(err => {
            // Handle other errors here.
            console.error(err);
            res.status(500).json({ error: "Internal Server Error" });
        });
});


app.put("/updateUser/:id", (req, res) => {
    const id = req.params.id;
    console.log(`Updating user with ID: ${id}`);
    console.log("Request body:", req.body);

    // Rest of your update logic...

    userModel.findByIdAndUpdate(id, { name: req.body.name, email: req.body.email, age: req.body.age })
        .then(result => {
            console.log("Update result:", result);
            res.json(result);
        })
        .catch(err => {
            console.error("Update error:", err);
            res.json(err);
        });
});





app.get("/", (req, res) => {
    userModel.find({})
        .then(result => res.json(result))
        .catch(err => res.json(err))
})

app.post("/createUser", (req, res) => {
    userModel.create(req.body)
        .then(users => res.json(users))
        .catch(err => res.json(err))
})


app.listen(3001, () => {
    connectDB()
    console.log("Server is Runnings")
})