import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import UpdateUser from './components/UpdateUser'
import CreateUser from './components/CreateUser'
import Users from './components/Users'


function App() {


  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Users />}></Route>
          <Route path='/update/:id' element={<UpdateUser />}></Route>
          <Route path='/create' element={<CreateUser />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
